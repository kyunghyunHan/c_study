#include "day06_lib.h"

int m = 10;

void swap(int * ap , int *bp){
    int temp;
    temp = *ap;
    *ap = *bp;
    *bp = temp;
}

void scanf_ary(int *ary,size_t len){

  for (size_t i = 0; i < len; i++){
      scanf("%d",ary++);
  }
}

void print_ary(int *ary,size_t len){
    for(size_t i = 0; i<len;i++){
        printf("%d",ary[i]);
    }
    printf("\n");
}
int findmax_ary(int *ary,size_t len){
    int ans = *ary;
     for(size_t i = 0; i<len;i++){
        if (ans<ary[i]){
            ans = ary[i];
        }
    }
    return ans;
}
int findmin_ary(int *ary,size_t len){
    int ans = *ary;
     for(size_t i = 0; i<len;i++){
        if (ans > ary[i]){
            ans = ary[i];
        }
    }
    return ans;
}

int sum_ary(int *ary,size_t len){
    int sum = 0;
     for(size_t i = 0; i<len;i++){
       sum+=ary[i];
    }
    return sum;
}
int avg_ary(int *ary,size_t len){
    int sum = 0;
     for(size_t i = 0; i<len;i++){
       sum+=ary[i];
    }
    return sum/len;
}